package com.company.subtask3;

public class VictorianCoffeeTable implements CoffeeTable {
    @Override
    public void hasLegs() {

    }
    @Override
    public void sitOn() {

    }
}