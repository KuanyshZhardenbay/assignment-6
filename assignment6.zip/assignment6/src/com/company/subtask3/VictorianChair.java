package com.company.subtask3;

public class VictorianChair implements Chair {
    @Override
    public void hasLegs() {

    }
    @Override
    public void sitOn() {

    }
}
