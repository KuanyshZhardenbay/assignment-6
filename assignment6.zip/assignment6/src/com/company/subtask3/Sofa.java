package com.company.subtask3;

public interface Sofa {
    public void hasLegs();
    public void sitOn();
}