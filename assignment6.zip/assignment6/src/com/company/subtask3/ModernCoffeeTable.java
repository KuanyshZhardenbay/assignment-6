package com.company.subtask3;

public class ModernCoffeeTable implements CoffeeTable {
    @Override
    public void hasLegs() {

    }
    @Override
    public void sitOn() {

    }
}