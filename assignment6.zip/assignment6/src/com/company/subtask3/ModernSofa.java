package com.company.subtask3;

public class ModernSofa implements Sofa {
    @Override
    public void hasLegs() {

    }
    @Override
    public void sitOn() {

    }
}