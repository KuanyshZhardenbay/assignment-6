package com.company.subtask3;

public class Main {
    public static void main(String[] args)
    {

    }
}