package com.company.subtask2;

class Boat extends transport  {
    double rate = 5;
    public double getRate() {
        return rate;
    }
}
