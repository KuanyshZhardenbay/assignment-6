package com.company.subtask2;

class Car extends transport {
    double rate = 10;
    public double getRate() {
        return rate;
    }
}
