package com.company.subtask2;

abstract class transport {
    double rate = 0;
    public double getRate() {
        return rate;
    }
}
