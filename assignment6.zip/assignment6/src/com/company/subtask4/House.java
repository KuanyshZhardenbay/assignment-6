package com.company.subtask4;

public class House {

}
