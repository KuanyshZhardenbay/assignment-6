package com.company.subtask4;

public class Director extends HouseBuilder {

}
